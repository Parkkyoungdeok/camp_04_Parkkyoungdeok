
<?php

	session_destroy();
?>
<meta charset="utf-8">
<script>alert("logout"); location.href="index.php"; </script>