package com.company.mondai1;

public class Word {
    public class word{
        String word1;
        String word2;
        String word3;
        String word4;
        String word5;



    }


    public class meaning{
        String meaning1;
        String meaning2;
        String meaning3;
        String meaning4;
        String meaning5;
    }

}
