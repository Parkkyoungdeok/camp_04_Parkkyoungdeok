package com.company;

public class Word {
    public class word{

    }

    public class meaning{

    }

}
